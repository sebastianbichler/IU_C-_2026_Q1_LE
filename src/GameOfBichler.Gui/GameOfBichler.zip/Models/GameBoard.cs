﻿using System;
using System.Collections.Generic;

namespace GameOfBichler.Gui.Models
{
    public class GameBoard
    {
        private readonly Dictionary<Position, IGridObject> _grid;

        public Player? Player { get; private set; }
        public Enemy? Enemy { get; private set; } // Muss public für ViewModel sein
        public bool IsGameOver { get; set; } = false;

        public int Width { get; }
        public int Height { get; }

        public event Action<string>? OnMessage;
        public event Action? OnBoardChanged;
        public event Action<Position>? OnExplosion;

        public GameBoard(int width, int height)
        {
            Width = width;
            Height = height;
            _grid = new Dictionary<Position, IGridObject>();
        }

        public void Initialize(Player player)
        {
            Player = player;
        }

        public void SpawnEnemy(int x, int y)
        {
            Enemy = new Enemy(new Position(x, y));
        }

        public IGridObject GetObjectAt(Position pos)
        {
            if (_grid.TryGetValue(pos, out var obj)) return obj;
            return new EmptyTile();
        }

        public void AddObject(int x, int y, IGridObject obj)
        {
            _grid[new Position(x, y)] = obj;
        }

        public void ClearTile(Position pos)
        {
            if (_grid.ContainsKey(pos))
            {
                _grid[pos] = new EmptyTile();
                OnBoardChanged?.Invoke();
            }
        }

        public void SendMessage(string msg) => OnMessage?.Invoke(msg);

        // --- HIER IST DIE NEUE LOGIK ---
        public void MoveEnemy()
        {
            if (IsGameOver || Enemy == null || Player == null) return;

            // 1. Ist der Gegner noch von einer Explosion betäubt?
            if (DateTime.Now < Enemy.StunnedUntil)
            {
                return; // Macht nichts, ruht sich aus
            }

            // 2. Richtung zum Spieler berechnen
            Position nextPos = CalculateNextEnemyStep();

            // 3. Interaktion prüfen
            IGridObject targetObj = GetObjectAt(nextPos);

            // FALL A: Es ist ein Stein -> SPRENGUNG!
            if (targetObj is Stone)
            {
                // 1. Stein logisch entfernen
                ClearTile(nextPos);

                // 2. BOOM! Event feuern (damit die GUI Sound & Bild abspielt)
                OnExplosion?.Invoke(nextPos);

                // 3. Nachricht & Betäubung
                SendMessage("BOOM! Stein gesprengt!");
                Enemy.StunnedUntil = DateTime.Now.AddSeconds(3); // 3 Sekunden Pause

                OnBoardChanged?.Invoke();
                return; // Bewegung stoppt hier
            }

            // FALL B: Weg ist frei (oder ein Item/Pfeil)
            if (targetObj.IsWalkable)
            {
                Enemy.Position = nextPos;

                // Prüfen auf Player-Kollision
                CheckEnemyCatch();

                // FALL C: Autobahn (Pfeile) benutzen
                // Wir nutzen eine Schleife, um ihn sofort bis zum Ende rutschen zu lassen
                HandleEnemySlide();
            }

            OnBoardChanged?.Invoke();
        }

        private Position CalculateNextEnemyStep()
        {
            int dx = Player.Position.X - Enemy!.Position.X;
            int dy = Player.Position.Y - Enemy.Position.Y;

            int stepX = 0;
            int stepY = 0;

            // Einfache Verfolgung auf der längeren Achse
            if (Math.Abs(dx) > Math.Abs(dy)) stepX = dx > 0 ? 1 : -1;
            else stepY = dy > 0 ? 1 : -1;

            Position preferredPos = new Position(Enemy.Position.X + stepX, Enemy.Position.Y + stepY);

            // Wenn blockiert (und kein Stein zum Sprengen), versuche Ausweichroute
            // Hinweis: Da er jetzt Steine sprengt, könnte man das Ausweichen auch weglassen, 
            // aber wir lassen es drin, falls er am Kartenrand hängt.
            IGridObject obj = GetObjectAt(preferredPos);
            if (!obj.IsWalkable && !(obj is Stone))
            {
                // Versuche andere Achse
                if (stepX != 0) // Wollte X, versuche Y
                {
                    stepY = dy > 0 ? 1 : -1;
                    if (dy == 0) stepY = 1; // Fallback
                    return new Position(Enemy.Position.X, Enemy.Position.Y + stepY);
                }
                else // Wollte Y, versuche X
                {
                    stepX = dx > 0 ? 1 : -1;
                    if (dx == 0) stepX = 1; // Fallback
                    return new Position(Enemy.Position.X + stepX, Enemy.Position.Y);
                }
            }

            return preferredPos;
        }

        private void HandleEnemySlide()
        {
            // Solange der Gegner auf einem Pfeil steht -> Weiterschieben
            // Begrenzung auf 20 Loops, um Endlosschleifen zu vermeiden
            int safetyCounter = 0;

            while (safetyCounter < 20)
            {
                IGridObject currentObj = GetObjectAt(Enemy!.Position);

                if (currentObj is Arrow arrow)
                {
                    // Wohin zeigt der Pfeil?
                    Position slideTarget = Enemy.Position.Add(arrow.ForceDirection);

                    // Ist das Ziel frei? (Gegner sprengt NICHT beim Rutschen, er stoppt sonst)
                    IGridObject slideObj = GetObjectAt(slideTarget);

                    // Kollisionscheck beim Rutschen
                    if (!slideObj.IsWalkable)
                    {
                        break; // Rutschen blockiert
                    }

                    // Bewegen
                    Enemy.Position = slideTarget;

                    // Hat er beim Rutschen den Spieler überfahren?
                    if (CheckEnemyCatch()) return;
                }
                else
                {
                    // Kein Pfeil mehr unter den Füßen -> Stop
                    break;
                }
                safetyCounter++;
            }
        }

        private bool CheckEnemyCatch()
        {
            if (Enemy!.Position.X == Player.Position.X && Enemy.Position.Y == Player.Position.Y)
            {
                IsGameOver = true;
                SendMessage("GAME OVER! Du wurdest erwischt.");
                return true;
            }
            return false;
        }

        // --- Bestehender Code ---
        public void MovePlayer(Direction dir)
        {
            if (IsGameOver) return;
            if (Player == null) return;

            Position targetPos = Player.Position.Add(dir);

            if (targetPos.X < 0 || targetPos.X >= Width || targetPos.Y < 0 || targetPos.Y >= Height) return;

            IGridObject targetObject = GetObjectAt(targetPos);
            if (!targetObject.IsWalkable) return;

            Player.Position = targetPos;
            targetObject.OnPlayerEnter(Player, this);
            OnBoardChanged?.Invoke();
        }

        public void Reset()
        {
            _grid.Clear();
            IsGameOver = false;
            Player = new Player(new Position(1, 1));
            // Enemy wird via SpawnEnemy gesetzt
            OnBoardChanged?.Invoke();
        }

        public bool IsTileEmpty(Position pos)
        {
            if (!_grid.ContainsKey(pos)) return true;
            return _grid[pos] is EmptyTile;
        }
    }
}