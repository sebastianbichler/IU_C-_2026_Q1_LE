﻿namespace GameOfBichler.Gui.Models
{
    public enum Direction { Up, Down, Left, Right }

    public struct Position
    {
        public int X { get; }
        public int Y { get; }

        public Position(int x, int y)
        {
            X = x;
            Y = y;
        }

        public Position Add(Direction dir)
        {
            return dir switch
            {
                Direction.Up => new Position(X, Y - 1),
                Direction.Down => new Position(X, Y + 1),
                Direction.Left => new Position(X - 1, Y),
                Direction.Right => new Position(X + 1, Y),
                _ => this
            };
        }
    }
}