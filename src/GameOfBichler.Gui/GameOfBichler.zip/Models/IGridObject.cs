﻿using System.Numerics;

namespace GameOfBichler.Gui.Models
{
    public interface IGridObject
    {
        bool IsWalkable { get; }
        // Wir übergeben das Board, damit das Objekt Aktionen auslösen kann (Dependency Injection Prinzip im kleinen Rahmen)
        void OnPlayerEnter(Player player, GameBoard board);
    }
}