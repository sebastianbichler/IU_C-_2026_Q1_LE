﻿using Avalonia.Media;
using Avalonia.Threading;
using Avalonia.Platform; // Für AssetLoader
using Avalonia.Media.Imaging;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using GameOfBichler.Gui.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading.Tasks; // Für Task.Delay

namespace GameOfBichler.Gui.ViewModels
{
    public partial class MainWindowViewModel : ViewModelBase
    {
        private readonly GameBoard _board;
        private string _statusText = "";

        // Timer und Assets
        private readonly DispatcherTimer _enemyTimer;

        // Nur noch Bilder, kein Sound mehr
        private readonly Bitmap _enemyImage;
        private readonly Bitmap _explosionImage;

        public ObservableCollection<TileViewModel> GridTiles { get; }

        public int Columns => _board.Width;
        public int Rows => _board.Height;

        public string StatusText
        {
            get => _statusText;
            set => SetProperty(ref _statusText, value);
        }

        public MainWindowViewModel()
        {
            // 1. ASSETS LADEN
            try
            {
                // Bilder laden
                _enemyImage = new Bitmap(AssetLoader.Open(new Uri("avares://GameOfBichler.Gui/Assets/krickel.jpg")));
                _explosionImage = new Bitmap(AssetLoader.Open(new Uri("avares://GameOfBichler.Gui/Assets/explosion.gif")));
            }
            catch (Exception ex)
            {
                StatusText = "Asset-Fehler: " + ex.Message;
                // Dummy-Zuweisung gegen Abstürze
                if (_enemyImage == null) _enemyImage = null!;
                if (_explosionImage == null) _explosionImage = null!;
            }

            // 2. BOARD INITIALISIEREN
            _board = new GameBoard(10, 10);
            var player = new Player(new Position(1, 1));
            _board.Initialize(player);

            // 3. EVENTS ABONNIEREN
            _board.OnBoardChanged += UpdateView;
            _board.OnMessage += (msg) => StatusText = msg;

            // Explosions-Event für die Grafik
            _board.OnExplosion += TriggerExplosionEffect;

            // 4. GRID INITIALISIEREN
            GridTiles = new ObservableCollection<TileViewModel>();
            for (int i = 0; i < _board.Width * _board.Height; i++)
            {
                GridTiles.Add(new TileViewModel());
            }

            // 5. TIMER INITIALISIEREN
            _enemyTimer = new DispatcherTimer();
            _enemyTimer.Interval = TimeSpan.FromSeconds(2);
            _enemyTimer.Tick += (s, e) =>
            {
                if (_board.IsGameOver)
                {
                    _enemyTimer.Stop();
                    return;
                }
                _board.MoveEnemy();
            };

            StartNewGame();
        }

        // Rein visuelle Explosion (kein Sound mehr)
        private async void TriggerExplosionEffect(Position pos)
        {
            int index = pos.Y * _board.Width + pos.X;
            if (index >= 0 && index < GridTiles.Count)
            {
                var tile = GridTiles[index];

                // Sperre aktivieren (damit UpdateView das GIF nicht sofort überschreibt)
                tile.IsExploding = true;

                // GIF anzeigen & Rot färben
                tile.Image = _explosionImage;
                tile.Symbol = "";
                tile.Color = Brushes.OrangeRed;

                // 0.5 Sekunden warten, damit man die Animation sieht
                await Task.Delay(500);

                // Sperre aufheben
                tile.IsExploding = false;
            }

            // Ansicht aktualisieren (Feld wird leer, da Stein weg ist)
            UpdateView();
        }

        [RelayCommand]
        public void StartNewGame()
        {
            _board.Reset();
            StatusText = "Lauf weg! Der rote Gegner kommt.";
            GenerateRandomLevel();

            _enemyTimer.Start();
            UpdateView();
        }

        private void GenerateRandomLevel()
        {
            var rand = new Random();
            int width = _board.Width;
            int height = _board.Height;

            // 1. Steine
            int stoneCount = 15;
            for (int i = 0; i < stoneCount; i++) PlaceRandomly(new Stone(), rand);

            // 2. Autobahn
            GenerateArrowChain(rand, chainLength: 6);
            GenerateArrowChain(rand, chainLength: 4);

            // 3. Sonnen
            int sunCount = 5;
            for (int i = 0; i < sunCount; i++) PlaceRandomly(new Sun(), rand);

            // 4. Ziel
            PlaceRandomly(new EndGoal(), rand);

            // 5. Gegner
            int attempts = 0;
            while (attempts < 100)
            {
                int x = rand.Next(_board.Width);
                int y = rand.Next(_board.Height);
                var pos = new Position(x, y);

                if ((x != 1 || y != 1) && _board.IsTileEmpty(pos))
                {
                    _board.SpawnEnemy(x, y);
                    break;
                }
                attempts++;
            }
        }

        private void GenerateArrowChain(Random rand, int chainLength)
        {
            Position currentPos;
            int attempts = 0;

            do
            {
                int x = rand.Next(_board.Width);
                int y = rand.Next(_board.Height);
                currentPos = new Position(x, y);
                attempts++;
                if (attempts > 100) return;
            }
            while (!_board.IsTileEmpty(currentPos) || (currentPos.X == 1 && currentPos.Y == 1));

            for (int i = 0; i < chainLength; i++)
            {
                var validNeighbors = new List<(Position pos, Direction dir)>();
                CheckNeighbor(currentPos, Direction.Up, validNeighbors);
                CheckNeighbor(currentPos, Direction.Down, validNeighbors);
                CheckNeighbor(currentPos, Direction.Left, validNeighbors);
                CheckNeighbor(currentPos, Direction.Right, validNeighbors);

                if (validNeighbors.Count == 0) break;

                var nextStep = validNeighbors[rand.Next(validNeighbors.Count)];
                _board.AddObject(currentPos.X, currentPos.Y, new Arrow(nextStep.dir));
                currentPos = nextStep.pos;
            }
        }

        private void CheckNeighbor(Position current, Direction dir, List<(Position, Direction)> list)
        {
            Position next = current.Add(dir);
            if (next.X >= 0 && next.X < _board.Width && next.Y >= 0 && next.Y < _board.Height)
            {
                if (_board.IsTileEmpty(next)) list.Add((next, dir));
            }
        }

        private void PlaceRandomly(IGridObject obj, Random rand)
        {
            int attempts = 0;
            while (attempts < 100)
            {
                int x = rand.Next(_board.Width);
                int y = rand.Next(_board.Height);
                var pos = new Position(x, y);

                if ((x != 1 || y != 1) && _board.IsTileEmpty(pos))
                {
                    _board.AddObject(x, y, obj);
                    break;
                }
                attempts++;
            }
        }

        public void Move(Direction dir)
        {
            _board.MovePlayer(dir);
        }

        private void UpdateView()
        {
            for (int y = 0; y < _board.Height; y++)
            {
                for (int x = 0; x < _board.Width; x++)
                {
                    int index = y * _board.Width + x;
                    var tileVM = GridTiles[index];

                    // Wenn Animation läuft, überspringen wir das Update für dieses Feld
                    if (tileVM.IsExploding) continue;

                    var pos = new Position(x, y);

                    // RESET
                    tileVM.Image = null;
                    tileVM.Symbol = "";
                    tileVM.Color = Brushes.WhiteSmoke;

                    // 1. Spieler
                    if (_board.Player.Position.X == x && _board.Player.Position.Y == y)
                    {
                        tileVM.Symbol = "P";
                        tileVM.Color = Brushes.CornflowerBlue;
                    }
                    // 2. Gegner
                    else if (_board.Enemy != null && _board.Enemy.Position.X == x && _board.Enemy.Position.Y == y)
                    {
                        tileVM.Image = _enemyImage;
                        tileVM.Color = Brushes.Transparent;
                    }
                    // 3. Objekte
                    else
                    {
                        var obj = _board.GetObjectAt(pos);
                        tileVM.Symbol = GetSymbolFor(obj);
                        tileVM.Color = GetColorFor(obj);
                    }
                }
            }
        }

        private string GetSymbolFor(IGridObject obj) => obj switch
        {
            Stone => "#",
            Sun => "☀",
            EndGoal => "⚑",
            Arrow a => GetArrowSymbol(a.ForceDirection),
            _ => ""
        };

        private IBrush GetColorFor(IGridObject obj) => obj switch
        {
            Stone => Brushes.DarkGray,
            Sun => Brushes.Gold,
            EndGoal => Brushes.ForestGreen,
            Arrow => Brushes.MediumTurquoise,
            _ => Brushes.WhiteSmoke
        };

        private string GetArrowSymbol(Direction dir) => dir switch
        {
            Direction.Up => "↑",
            Direction.Down => "↓",
            Direction.Left => "←",
            Direction.Right => "→",
            _ => "?"
        };
    }
}