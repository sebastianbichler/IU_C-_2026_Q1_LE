﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace GameOfBichler.Gui.ViewModels;

public abstract class ViewModelBase : ObservableObject
{
    // Leer ist hier korrekt. 
    // Alle Funktionen (wie SetProperty) kommen automatisch von "ObservableObject".
}