using System.Reflection;

namespace GAE.Shared.Core;

/// <summary>
/// Runtime reflection-based game discovery service.
/// This is the COMPARISON implementation to demonstrate the overhead
/// of reflection vs. the compile-time source generator approach.
///
/// Performance implications (cf. Coulson et al. 2004; Warren 2016):
/// - GetTypes() scans the full metadata table of each assembly
/// - Security checks are performed on every reflection call
/// - No JIT inlining possible for reflected method calls
/// </summary>
public class DiscoveryService
{
    /// <summary>
    /// Discovers all IArcadeGame implementations in all loaded assemblies
    /// using runtime reflection. This approach has measurable overhead
    /// and is not compatible with Native AOT trimming.
    /// </summary>
    public IReadOnlyList<IArcadeGame> DiscoverViaReflection()
    {
        var games = new List<IArcadeGame>();
        var assemblies = AppDomain.CurrentDomain.GetAssemblies();

        foreach (var assembly in assemblies)
        {
            Type[] types;
            try
            {
                types = assembly.GetTypes();
            }
            catch (ReflectionTypeLoadException ex)
            {
                // Some assemblies may fail to load all types
                types = ex.Types.Where(t => t is not null).ToArray()!;
            }

            var gameTypes = types
                .Where(t => typeof(IArcadeGame).IsAssignableFrom(t)
                         && !t.IsInterface
                         && !t.IsAbstract
                         && t.GetConstructor(Type.EmptyTypes) is not null);

            foreach (var type in gameTypes)
            {
                if (Activator.CreateInstance(type) is IArcadeGame game)
                {
                    games.Add(game);
                }
            }
        }

        return games.AsReadOnly();
    }
}
