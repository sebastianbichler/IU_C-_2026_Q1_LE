namespace GAE.Shared.Core;

/// <summary>
/// Classifies discovered games using C# Pattern Matching (switch expressions).
/// Demonstrates how compile-time discovery (Source Generator) and
/// runtime classification (Pattern Matching) work together.
///
/// Pattern Matching (C# 9+) provides type-safe branching logic
/// without explicit casting or if-else chains.
/// </summary>
public static class GameClassifier
{
    /// <summary>
    /// Categorizes a game based on its properties using property patterns.
    /// </summary>
    public static string Categorize(IArcadeGame game) => game switch
    {
        // Property Pattern: check the Name property
        { Name: var name } when name.Contains("Snake") => "Classic",
        { Name: var name } when name.Contains("Mine") => "Puzzle",
        { Name: var name } when name.Contains("Pac") => "Arcade",

        // Discard pattern: default category
        _ => "General"
    };

    /// <summary>
    /// Returns a formatted display string for the dashboard menu.
    /// </summary>
    public static string FormatForDashboard(IArcadeGame game)
    {
        var category = Categorize(game);
        return $"[{category}] {game.Name}";
    }
}
