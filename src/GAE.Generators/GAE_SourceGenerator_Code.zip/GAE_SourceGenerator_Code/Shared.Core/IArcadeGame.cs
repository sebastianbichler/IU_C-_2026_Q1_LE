namespace GAE.Shared.Core;

/// <summary>
/// Core interface for all arcade games in the Grand Arcade Ecosystem (GAE).
/// Every game module must implement this interface to participate in the hub.
/// The ArcadeDiscoveryGenerator discovers implementations at compile time.
/// </summary>
public interface IArcadeGame : IDisposable
{
    /// <summary>
    /// Display name of the game.
    /// </summary>
    string Name { get; }

    /// <summary>
    /// Called once when the game is loaded into the hub.
    /// </summary>
    void Initialize();

    /// <summary>
    /// Called every frame with the elapsed time since the last frame.
    /// </summary>
    void Update(double deltaTime);

    /// <summary>
    /// Called every frame to render the current game state.
    /// </summary>
    void Render();

    /// <summary>
    /// Called when the game is unloaded from the hub.
    /// </summary>
    void Shutdown();
}

/// <summary>
/// Immutable record for storing highscores.
/// Uses C# record for value equality and immutability (cf. DDD patterns, Gruppe 4).
/// </summary>
public record Highscore(string Player, int Value, DateTime Date, string GameName);
