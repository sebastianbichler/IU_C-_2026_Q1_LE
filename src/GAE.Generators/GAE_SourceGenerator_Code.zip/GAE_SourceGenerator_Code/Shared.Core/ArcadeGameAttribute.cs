namespace GAE.Shared.Core;

/// <summary>
/// Marker attribute for arcade game classes.
/// Classes annotated with this attribute and implementing IArcadeGame
/// will be automatically discovered by the ArcadeDiscoveryGenerator
/// at compile time and registered in the generated GameRegistry.
///
/// This is an example of "explicit metadata" (cf. Ingebrigtsen 2023, Ch. 2 & 5):
/// The attribute serves as an explicit opt-in mechanism, ensuring only
/// intentionally marked classes are registered as games.
/// </summary>
[AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = false)]
public sealed class ArcadeGameAttribute : Attribute
{
    /// <summary>
    /// Optional display name for the game in the dashboard menu.
    /// If not set, the class name is used.
    /// </summary>
    public string? DisplayName { get; init; }

    /// <summary>
    /// Optional description shown in the dashboard.
    /// </summary>
    public string? Description { get; init; }
}
