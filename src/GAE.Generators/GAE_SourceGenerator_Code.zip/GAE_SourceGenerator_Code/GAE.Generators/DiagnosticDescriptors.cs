using Microsoft.CodeAnalysis;

namespace GAE.Generators;

/// <summary>
/// Defines custom compiler diagnostics for the GAE Arcade Discovery system.
/// These diagnostics enforce correctness of plugin implementations at compile time.
/// </summary>
internal static class DiagnosticDescriptors
{
    /// <summary>
    /// GAE001: Class has [ArcadeGame] attribute but does not implement IArcadeGame.
    /// </summary>
    public static readonly DiagnosticDescriptor MissingInterfaceRule = new(
        id: "GAE001",
        title: "Missing IArcadeGame implementation",
        messageFormat: "Class '{0}' has [ArcadeGame] attribute but does not implement IArcadeGame interface",
        category: "GAE.Design",
        defaultSeverity: DiagnosticSeverity.Error,
        isEnabledByDefault: true,
        description: "Classes annotated with [ArcadeGame] must implement the IArcadeGame interface to be discoverable by the game registry.");

    /// <summary>
    /// GAE002: Class implements IArcadeGame but has no public parameterless constructor.
    /// </summary>
    public static readonly DiagnosticDescriptor MissingParameterlessConstructorRule = new(
        id: "GAE002",
        title: "Missing public parameterless constructor",
        messageFormat: "Class '{0}' implements IArcadeGame but has no public parameterless constructor. The source generator cannot instantiate it.",
        category: "GAE.Design",
        defaultSeverity: DiagnosticSeverity.Error,
        isEnabledByDefault: true,
        description: "Game classes must have a public parameterless constructor so the auto-generated registry can create instances.");
}
