namespace GAE.Generators;

/// <summary>
/// Holds information about a discovered arcade game class.
/// Used internally by the source generator pipeline.
/// </summary>
internal sealed class GameInfo
{
    public string FullTypeName { get; }
    public string DisplayName { get; }
    public bool HasValidConstructor { get; }

    public GameInfo(string fullTypeName, string displayName, bool hasValidConstructor)
    {
        FullTypeName = fullTypeName;
        DisplayName = displayName;
        HasValidConstructor = hasValidConstructor;
    }
}
