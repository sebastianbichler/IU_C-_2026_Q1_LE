using GAE.Shared.Core;

namespace GAE.Generators.Demo;

// Absichtlich fehlerhaft für Teil-3-Demo:
// Hat [ArcadeGame], implementiert aber NICHT IArcadeGame.
[ArcadeGame(DisplayName = "Broken", Description = "Diagnostic demo class")]
public class BrokenGame
{
    public string Name => "Broken";
}
