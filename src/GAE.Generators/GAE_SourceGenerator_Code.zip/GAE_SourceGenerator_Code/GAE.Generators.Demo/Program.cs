using System.Diagnostics;
using GAE.Shared.Core;

namespace GAE.Generators.Demo;

/// <summary>
/// Demo program that compares Source Generator discovery vs. Reflection discovery.
/// This demonstrates the key scientific finding of Gruppe 5:
/// Compile-time metaprogramming eliminates runtime overhead.
/// </summary>
public static class Program
{
    public static void Main()
    {
        Console.WriteLine("=============================================================");
        Console.WriteLine("  GAE — Gruppe 5: Source Generator vs. Reflection Demo");
        Console.WriteLine("  Wissenschaftliche Frage: Vorteile von Source Generators");
        Console.WriteLine("  gegenueber Runtime-Reflection bei Plugin-Discovery");
        Console.WriteLine("=============================================================");
        Console.WriteLine();

        // ── Part 1: Source Generator Discovery (compile-time) ──
        Console.WriteLine("--- [1] Source Generator Discovery (Compile-Time) ---");
        Console.WriteLine();

        var sw = Stopwatch.StartNew();
        var generatorGames = GAE.Generated.GameRegistry.CreateAll();
        sw.Stop();

        Console.WriteLine($"  Discovered {generatorGames.Count} game(s) in {sw.Elapsed.TotalMilliseconds:F4} ms");
        Console.WriteLine();

        foreach (var game in generatorGames)
        {
            var category = GameClassifier.Categorize(game);
            Console.WriteLine($"  -> {game.Name} [{category}]");
            game.Initialize();
        }

        Console.WriteLine();

        // ── Part 2: Telemetry (compile-time generated) ──
        Console.WriteLine("--- [2] Compile-Time Telemetry ---");
        Console.WriteLine();
        Console.WriteLine($"  Total games discovered at build time: {GAE.Generated.GameTelemetry.TotalGamesDiscovered}");
        Console.WriteLine($"  Game names: {string.Join(", ", GAE.Generated.GameTelemetry.GameNames)}");
        Console.WriteLine();

        // ── Part 3: Reflection Discovery (runtime) for comparison ──
        Console.WriteLine("--- [3] Reflection Discovery (Runtime) for Comparison ---");
        Console.WriteLine();

        var discoveryService = new DiscoveryService();

        sw.Restart();
        var reflectionGames = discoveryService.DiscoverViaReflection();
        sw.Stop();

        Console.WriteLine($"  Discovered {reflectionGames.Count} game(s) in {sw.Elapsed.TotalMilliseconds:F4} ms");
        Console.WriteLine();

        foreach (var game in reflectionGames)
        {
            Console.WriteLine($"  -> {game.Name} [{GameClassifier.Categorize(game)}]");
        }

        Console.WriteLine();

        // ── Part 4: Pattern Matching Demo ──
        Console.WriteLine("--- [4] Pattern Matching Classification ---");
        Console.WriteLine();

        foreach (var game in generatorGames)
        {
            Console.WriteLine($"  {GameClassifier.FormatForDashboard(game)}");
        }

        Console.WriteLine();
        Console.WriteLine("=============================================================");
        Console.WriteLine("  Done. The source generator discovered all games at compile");
        Console.WriteLine("  time with zero runtime overhead. Check the Generated/");
        Console.WriteLine("  folder to inspect the auto-generated GameRegistry.g.cs.");
        Console.WriteLine("=============================================================");

        // Cleanup
        foreach (var game in generatorGames)
        {
            game.Dispose();
        }
    }
}
