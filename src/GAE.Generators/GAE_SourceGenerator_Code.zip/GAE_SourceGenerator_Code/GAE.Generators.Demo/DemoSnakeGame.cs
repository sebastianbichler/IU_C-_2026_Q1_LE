using GAE.Shared.Core;

namespace GAE.Generators.Demo;

/// <summary>
/// A minimal Snake game implementation for testing the source generator.
/// Annotated with [ArcadeGame] and implements IArcadeGame.
/// The source generator should discover this class and register it.
/// </summary>
[ArcadeGame(DisplayName = "Snake Classic", Description = "The classic Snake game")]
public class DemoSnakeGame : IArcadeGame
{
    public string Name => "Snake";

    public void Initialize()
        => Console.WriteLine("  [Snake] Initialized");

    public void Update(double deltaTime)
        => Console.WriteLine($"  [Snake] Update (dt={deltaTime:F3})");

    public void Render()
        => Console.WriteLine("  [Snake] Rendered");

    public void Shutdown()
        => Console.WriteLine("  [Snake] Shut down");

    public void Dispose()
        => Shutdown();
}
