using GAE.Shared.Core;

namespace GAE.Generators.Demo;

/// <summary>
/// A minimal Minesweeper game implementation for testing the source generator.
/// Annotated with [ArcadeGame] and implements IArcadeGame.
/// </summary>
[ArcadeGame(DisplayName = "Minesweeper", Description = "Find the mines!")]
public class DemoMinesGame : IArcadeGame
{
    public string Name => "Minesweeper";

    public void Initialize()
        => Console.WriteLine("  [Mines] Initialized");

    public void Update(double deltaTime)
        => Console.WriteLine($"  [Mines] Update (dt={deltaTime:F3})");

    public void Render()
        => Console.WriteLine("  [Mines] Rendered");

    public void Shutdown()
        => Console.WriteLine("  [Mines] Shut down");

    public void Dispose()
        => Shutdown();
}
